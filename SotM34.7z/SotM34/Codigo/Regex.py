import requests, re, json


def extractFromRegularExpresion(regex, file):
    if file:
        data=""
        with open(file,"rt") as f:
            data=f.read()
        return re.findall(regex,data)
    return None
    
def apiRequestData(data):
    JsonData = []
    if not data:
        print("No hay datos para procesar.")
        return

    URI = "http://ip-api.com/json/"
    ip_seen = set()

    for ip, path, code in data:
        if ip in ip_seen:
            continue  # Ya procesada

        ip_seen.add(ip)
        formatData = {"ip": ip, "code": code}

        try:
            response = requests.get(f"{URI}{ip}").json()
            formatData["country"] = response.get("country")
            formatData["city"] = response.get("city")
        except Exception as e:
            formatData["country"] = None
            formatData["city"] = None

        JsonData.append(formatData)
    return JsonData


regex = r"^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*?\b[A-Z]{3,7}\b\s(.*?)\s.*?(\d{3})"
resultado0 = extractFromRegularExpresion(regex, "http\\access_log")
resultado1 = extractFromRegularExpresion(regex, "http\\access_log.1")
resultado2 = extractFromRegularExpresion(regex, "http\\access_log.2")
resultado3 = extractFromRegularExpresion(regex, "http\\access_log.3")
resultado4 = extractFromRegularExpresion(regex, "http\\access_log.4")
resultado5 = extractFromRegularExpresion(regex, "http\\access_log.5")
resultado6 = extractFromRegularExpresion(regex, "http\\access_log.6")


resultado_0 = apiRequestData(resultado0)
resultado_1 = apiRequestData(resultado1)
resultado_2 = apiRequestData(resultado2)
resultado_3 = apiRequestData(resultado3)
resultado_4 = apiRequestData(resultado4)
resultado_5 = apiRequestData(resultado5)
resultado_6 = apiRequestData(resultado1)

print()





