import requests, re, json


def extractFromRegularExpresion(regex, file):
    if file:
        data=""
        with open(file,"rt") as f:
            data=f.read()
        return re.findall(regex,data)
    return None
    
def apiRequestData(data):
    JsonData = []
    if not data:
        print("No hay datos para procesar.")
        return

    URI = "http://ip-api.com/json/"
    ip_seen = set()

    for ip, path, code in data:
        if ip in ip_seen:
            continue  # Ya procesada

        ip_seen.add(ip)
        formatData = {"ip": ip, "code": code}

        try:
            response = requests.get(f"{URI}{ip}").json()
            formatData["country"] = response.get("country")
            formatData["city"] = response.get("city")
        except Exception as e:
            formatData["country"] = None
            formatData["city"] = None

        JsonData.append(formatData)
    return JsonData


regex = r"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*?\b[A-Z]{3,7}\b\s(.*?)\s.*?(\d{3})"
resultado0 = extractFromRegularExpresion(regex, "http\\access_log")
resultado1 = extractFromRegularExpresion(regex, "http\\access_log.1")
resultado2 = extractFromRegularExpresion(regex, "http\\access_log.2")
resultado3 = extractFromRegularExpresion(regex, "http\\access_log.3")
resultado4 = extractFromRegularExpresion(regex, "http\\access_log.4")
resultado5 = extractFromRegularExpresion(regex, "http\\access_log.5")
resultado6 = extractFromRegularExpresion(regex, "http\\access_log.6")


resultado_0 = apiRequestData(resultado0)
resultado_1 = apiRequestData(resultado1)
resultado_2 = apiRequestData(resultado2)
resultado_3 = apiRequestData(resultado3)
resultado_4 = apiRequestData(resultado4)
resultado_5 = apiRequestData(resultado5)
resultado_6 = apiRequestData(resultado1)

def imprimir_resultado(data):
    print(f"{'IP':<20}{'País':<20}{'Código':<10}")
    print("-" * 65)
    for entrada in data:
        ip = entrada.get("ip", "")
        pais = entrada.get("country") or "Desconocido"
        codigo = entrada.get("code", "") or ""
        print(f"{ip:<20}{pais:<20}{codigo:<10}")


print("Access log ")
imprimir_resultado(resultado_0)
print("Access log 1")
imprimir_resultado(resultado_1)
print("Access log 2")
imprimir_resultado(resultado_2)
print("Access log 3")
imprimir_resultado(resultado_3)
print("Access log 4")
imprimir_resultado(resultado_4)
print("Access log 5")
imprimir_resultado(resultado_5)
print("Access log 6")
imprimir_resultado(resultado_6)







